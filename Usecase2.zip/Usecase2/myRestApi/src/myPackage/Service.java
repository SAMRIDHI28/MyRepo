package myPackage;

public class Service {
public static void TeamInfoService{
	private TeamDataSource teamDd;
	
	public void addTeamInfo(teamName,userName){
		Integer userTeamCount = teamdB.getTeamCountByUser(userName);
		if(userTeamCount<3){
			teamdB.addTeam(teamName,userName,userTeamCount+1);
		}
		else{
			system.out.println("user has created maximum possible teams");
		}
		public void addUser(userName,Team){
			teamDd.addUser(userName,Team);
		}
	}
}
}
