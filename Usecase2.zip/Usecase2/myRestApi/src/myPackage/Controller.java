package myPackage;
@Controller
public class Controller {
public static void TeamDataController{
	private TeamDataService teamDataService;
	@PutMapping('teamName')
	public void addTeam(String teamName,string userName){
		teamDataService.addTeamInfo(teamName,userName)
	}
	@PutMapping('userInfo')
	public void addUserToTeam(String userName required = true, string team required = false, default ='unassigned'){
		teamDataService.addUserToTeam(teamName,userName)
	}
	}
}
}
