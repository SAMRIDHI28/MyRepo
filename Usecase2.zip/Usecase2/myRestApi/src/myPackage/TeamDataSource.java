package myPackage;

public class TeamDataSource {
	
private static final string ADD_TEAM = "INSERT INTO TABLE_INFO(TableName,DateCreated,Number,CreatedBy) VALUES(1,sysDate,3,2)";

private static final string GET_TEAM_COUNT = "SELECT COUNT(*) FROM TABLE_INFO WHERE CreatedBy = '1'";

private static final String ADD_USER = "INSERT INTO USER_INFO(userName,DateAdded,Team) VALUES(1,sysdate,2)";

private JdbcTemplate jdbcTemplate;
public integer getTeamCountByUser(String userName){
	return jdbcTemplate.query(GET_TEAM_COUNT).parameter(1,"userName").execute();
}
pulic void addTeam(String teamName,String createdBy, Integer Count){
jdbcTemplate.query(ADD_TEAM).parameter(1,teamName).parameter(2,createdBy).parameter(3,Count).execute();
}

public void addUser(String userName, string teamName){
	jdbcTemplate.query(ADD_USER).parameter(1,userName).parameter(2,teamName).execute();
}
}

